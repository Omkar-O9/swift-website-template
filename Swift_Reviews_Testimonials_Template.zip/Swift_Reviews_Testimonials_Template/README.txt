SWIFT TECHNOPLAST - REVIEWS / TESTIMONIALS TEMPLATE

Folder structure:

Swift_Reviews_Testimonials_Template/
│
├── index.html
├── css/
│   └── style.css
├── js/
│   └── script.js
└── img/
    ├── banner.jpg
    ├── cta-background.jpg
    ├── google-review-01.jpg
    ├── indiamart-review-01.jpg
    ├── tradeindia-review-01.jpg
    ├── other-review-01.jpg
    ├── customer-logo-01.png
    ├── customer-logo-02.png
    ├── customer-logo-03.png
    ├── customer-logo-04.png
    └── customer-logo-05.png

Replace the placeholder images in /img/ with the actual Swift Technoplast
banner, review screenshots and customer logos.

The page is intentionally separated into:
- index.html = page structure/content
- css/style.css = complete styling
- js/script.js = review filters + screenshot lightbox
- img/ = all page images

The existing Swift Technoplast header and footer can be inserted into index.html
from the current website template.
